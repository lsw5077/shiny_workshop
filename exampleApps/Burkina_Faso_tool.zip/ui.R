library(shiny)

#setwd('U:\\uf\\sesync course\\1c shiny basics policy D\\burkina_faso_tool')
uni=read.csv('unique locations.csv',as.is=T)$x #regions

# Define UI for dataset viewer application
shinyUI(pageWithSidebar(
  
  # Application title.
  headerPanel("Probability of malaria infection"),
  
  sidebarPanel(
    width=3,
    selectInput("region", "Choose region:",choices = uni),
    selectInput("fever2wk", "Fever in the past 2 weeks?",choices = c('Yes','No')),
    selectInput("gender", "Male?",choices = c('Yes','No')),    
    h5("Map of Burkina Faso"),
    plotOutput('map',width=150,height=150),
    h6("If you have questions regarding this webpage, please contact us: Denis Valle (drvalle@ufl.edu)")
  ),
  
  mainPanel(
    plotOutput('plot1'),
    p('Legend:',style = "font-family: 'times'; font-size:14pt"),
    div("Black circle: pre-test probability of infection",
      style="font-family: 'times'; font-size:10pt"),
    div("Blue circle: probability of infection for RDT negative children",
        style="font-family: 'times'; font-size:10pt; color:blue"),
    div("Red circle: probability of infection for RDT positive children",
        style="font-family: 'times'; font-size:10pt; color:red"),
    p('',style = "font-family: 'times'; font-size:14pt"),
    div("Observation: Vertical lines are 95% credible intervals. These figures were created based on statistical models fit to Burkina Faso's 2010 Demographic and Health Survey data. A detailed description of these data, statistical models, and the rationale for this tool is available in Valle et al. (in review).",style = "font-family: 'times'; font-size:10pt")
  )
))
