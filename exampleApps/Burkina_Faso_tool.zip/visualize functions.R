#------------------------------------------------------------------------
#get each panel
panel.graph=function(dat1,xaxis,yaxis,margin1,margin2){
  #--------------------------------------------------------------------------------  
  #get baseline malaria prevalence
  anos=paste('age.cat',1:4,sep='')
  dat2=unique(dat1[,c(anos,'lo.pinf','med.pinf','hi.pinf')])
  plot(NA,NA,ylim=c(0,1),xlim=c(-0.5,4.5),xaxt='n',yaxt='n')
  if (xaxis) axis(side=1,at=0:4,cex.axis=1.5)
  if (yaxis) axis(side=2,at=seq(0.2,0.8,by=0.2),cex.axis=1.5)
  abline(v=seq(from=0.5,to=3.5,by=1),col='grey',lty=3)
  abline(h=seq(from=0.1,to=0.9,by=0.1),col='grey',lty=3)
  points(0:4,dat2[,'med.pinf'],cex=2,pch=19)
  for (i in 0:4) lines(rep(i,2),dat2[i+1,c('lo.pinf','hi.pinf')])
  
  #--------------------------------------------------------------------------------  
  #get malaria risk given rdt results
  
  #if RDT is positive
  z=unique(dat1[,c(anos,'lo.rdt1','med.rdt1','hi.rdt1')])
  points(0:4+margin1,z[,'med.rdt1'],cex=2,pch=19,col='red')  
  for (i in 0:4) lines(rep(i,2)+margin1,z[i+1,c('lo.rdt1','hi.rdt1')],col='red')
  
  #if RDT is negative
  z=unique(dat1[,c(anos,'lo.rdt0','med.rdt0','hi.rdt0')])
  points(0:4-margin1,z[,'med.rdt0'],cex=2,pch=19,col='blue')  
  for (i in 0:4) lines(rep(i,2)-margin1,z[i+1,c('lo.rdt0','hi.rdt0')],col='blue')
}
