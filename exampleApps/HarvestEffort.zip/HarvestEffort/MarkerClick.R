#React to click event
observe({
  click<-input$map_marker_click
  if(is.null(click))
    return()
  myHarvPlot = input$area #myHarvPlot = spDf[which(spDf$x == click$lng) && which(spDf$y == click$lat), ]
  
  print(spDf[which(spDf$x == click$lng) && which(spDf$y == click$lat), ])
  print("clicked")
  
  myHarvLim = input$amount
  myMaxTime = input$effort
  myMinSize = input$size
  returnShells = input$shell
  param = c(myHarvLim, myMaxTime, myMinSize, myHarvPlot, returnShells)
  
  localUpdate(param)
})