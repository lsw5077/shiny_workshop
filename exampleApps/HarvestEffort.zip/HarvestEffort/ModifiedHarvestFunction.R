#Simple age-structured mod with realistic oyster parms
#   added time varying effort thus using a hr[t] calculation (hr[t]=1-exp(-F[t])), where F[t]=q*effort[t] and everywhere assuming t is a timestep (I use "i" in the model below)
#   added in simple shell dynamics following some work from Carl. The intitial shell could be played with and others will probably disagree with the conversion of length to shell, but this is a start
#   added in link between shell and habitat. But made it a logistic relationship, saying you can lose a lot of shell before you "tip" over a point where habitat decreases.
#   Note, this is a very simple way of demonstrating alternative stable states. Oysters are resistance to harvest so long as effort isn't too great.
#         but at high effort, system will collapse (try changing Et in line 38 to 135, but then go up to 150). Right now the s.d. of the logistic is small so the relationship is 
#         sharp, which is probably unrealistic (but maybe not given 3D shape of reef). 
#   Note that L82-86 shows why this happens (scrap code with fake var names just for looking)


#   What remains to be done: 
#         - put in a spatial context, consider dispersal
#         - dig into Carl's orig oyster model to sort out how he was calculating intitial shell (i.e. shell so model is mostly balanced absent fishing). I did it numerically here (i.e. plug & play)
#         - try to fit to data
#         - explore management frameworks

rm(list = ls())

################################################################################
# Parameters #
################################################################################
###Time
years = 1                     #just time steps--most of model calibrated for monthly, probably.

### Constants, life history and fishery ###
amax = 36       #maximum age, (or years)
Ro = 1000       #recruitment at unfished conditions
CR = 8          #recruitment compensation ratio
vbk = 0.1      #von bertelanfy metabolic parameter
vblinf = 95    #von bertelanfy length infinity parameter
vbt0 = 0        #von bertelanfy t0 parameter
alw = 6e-8    # length weight alometry parameter, this came from Carl as (1/28)/(85)^3--so probably a metabolic derivation. 
alwb = 3        #length weight alometry b parm
wmat = alw*(0.5*vblinf)^alwb       #weight at maturity
M = 0.1        #natural mortality

#fishery
vlh = 65        #length at 50% vulnerability
vsd = 5         #standard deviation of length at 50% vulnerability
q = 0.005       #catchbility, only used if you're using effort (U= 1-exp(-F)), where F=q*effort. This q is just guessed, may need to be 1 or 2 orders of mag larger
sdobs = 0.6     #the standard deviation of the observation error (i.e. mean 0, sd = sdobs), can be considered the coefficient of variation in observation error
sdpro = 0.0001  #the standard devation of the process effor, same as above
#adding effort: U=.25, which is an F of about 0.28. if q=0.005, Effort necesary to cause an F of 0.28 is F/q, or about 56.
#Et = 125     # Run in function, not needed #56 matches a hr of 0.25, but explore how effort changes things--dropping effort to 35 makes a big difference

###############
### function open
###############
fun = function(effort, habitat){
  #initializing U for Lfished and following calculations
  U=1-exp(-(effort*q))
  
  ### Age-specifc vectors ###
  Age = seq(1,amax)                             #Age
  TL = vblinf*(1-exp(-vbk*(Age-vbt0)))          #Total length
  Wt = (alw*(TL)^alwb)                          #Weight
  Vul = 1/(1+exp(-(TL-vlh)/vsd))                #Vulnerability
  Surv = (1+vblinf/TL*(exp(vbk)-1))^(-M/vbk)    #Survival in each time step, could have alterantively done: exp(-Madult*linf/base_len)
  Lo = vector(length=amax); Lo[1]=1;  for (i in 2:amax){Lo[i]=Lo[i-1]*Surv[i-1]}; #Lo[Amax] = Lo[(Amax-1)]*surv[(Amax-1)]/(1-surv[(Amax-1)])       #survivorship in unfished condtions with special survivorship for terminal age
  Lfished = vector(length=amax); Lfished[1]=1;  for (i in 2:amax){Lfished[i]=Lfished[i-1]*Surv[i-1]*(1-U*Vul[i-1])}; #Lfished[Amax] = Lfished[(Amax-1)]*surv[(Amax-1)]*(1-U*vul[(Amax-1)])/(1-surv[(Amax-1)]*(1-U*vul[(Amax-1)]))       #Standard with special calculation for terminal fished survivorship
  Fec = ifelse((Wt-wmat)<0,0,Wt-wmat)           #Fecundity
  
  ### Calculations from vectors ###
  epro = sum(Lo*Fec)                    #eggs-per-recruit unfished conditions
  eprf = sum(Lfished*Fec)               #eggs-per-recruit fished conditions
  bpro = sum(Wt,Lo)                     #biomass-per-recruit unfished conditions
  npro = sum(Lo)                        #numbers-per-recruit unfished conditions
  vbpro = sum(Vul*Wt*Lo)                #vulnerable biomass per recruit unfished conditions
  vbprf = sum(Vul*Wt*Lfished)           #vulnerable biomiass per recruit fished conditions
  spr = epro/eprf                       #spawning potential ratio
  bo = Ro*bpro                          #biomass at unfished condtions
  no = Ro*npro                          #numbers at unfished conditions
  vbo = Ro*vbpro                        #vulnerable biomass at unfished conditions
  
  #recruitment parms and calcs#
  bha = CR/epro                         #beverton holt a parm
  bhb = (CR-1)/(Ro*epro)                #beverton holt b parm
  #r.eq = (bha*eprf-1)/(bhb*eprf)       #equilibrium recruitment, should not be used here if assuming habitat-based recruitment (i.e. reparameterization of a & b based on H)
  #yield.eq = U*vbprf*r.eq              #equilibrium yield--standard calc, but not applicable here unless using U and constant recruitment
  
  #Shell stuff
  shell_surv = 0.8    #survival rate of dead shell (i.e. some shell remains and is useful, other disintegrates)
  cstar=1             #switch for whether a or b parm (of beverton holt) affected by habitat suitable for recruitment (cstar=1 corresponds to b parm, thus affecting carrying capacity rather than max survival rate). Walters et al 2007 for reference
  shell_init = 360.3       #initial shell, guessed by fiddling, but there's a relationship here that I'm not aware of. Can be done with Carl equilibrium approach from Ed's/Carl's age structured model
  #to explain, you can turn off fishing by Et=0, then run model and set shell_init to the total shell. BUT see above, this isn't very biologically based right now,
  #thus until shell is calculated in a more biologically designed fashion, shell functions as a scalar.
  #logistic relationship between habitat for recruitment (H in model below) and shell
  sht = 0.25*shell_init             #saying there's a threshold, below which there's not enough shell for good habitat. technically the inflection point
  shsd = 5                          #standard deviation, this determines how sharp the sigmoidal-shaped relationship between shell and habitat is. 
  #Scrap relationships between shell and available habitat. These will be implemented in model
  sh = seq(0,shell_init, by=1)      #sequence of shell, analogous to "shell" (shell[i]) in model.
  hab = 1/(1+exp(-(sh-sht)/shsd))   #simple habitat, allowing habitat to go to zero
  hab1 = pmax(0.1, 1/(1+exp(-(sh-sht)/shsd)))   #This is a "safety net" function where we say look habitat can't be worse than 0.1 no matter what happens to shell.
  plot(sh,hab, type="l", lwd=2, col="green"); lines(sh,hab1, col="blue", lwd=2) #just looking at it
  
  
  ###setting up space for model outputs
  eggs = NULL; N=NULL; B=NULL; VB=NULL;  yield = NULL; obs_err = NULL; proc_err = NULL;
  shell=NULL; shell_add=NULL; eff=NULL; hr=NULL; ahab=NULL; bhab=NULL;
  H=NULL; H_null=NULL; H_lin=NULL; H_thresh=NULL; H_threshSafe=NULL;      #H is the operational Habitat, each other are alternative assumptions that can be selected
  nage = matrix(0,years,amax)                                             #set up matrix for age-structured abundance
  
  
  ### Model ###
  
  ### Initilization (year one) 
  #initializing first year of all year dependent values, note, these must go in a specific order
  nage[1,]=Ro*Lo                            #numbers at age, year 1
  eggs[1]= sum(Fec*nage[1,])                #first value of eggs !!!! need to check to make sure this is correct
  proc_err[1] = 0 #rnorm(1,0,sdpro)         #first value of process error
  N[1] = sum(nage[1,])                      #first value of total numbers
  B[1] = sum(nage[1,]*Wt)                   #first value of total biomass
  VB[1] = sum(nage[1,]*Wt*Vul)              #first value of vulernable biomass
  obs_err[1] = 0 #rnorm(1,0,sdobs)          #first value of observation error
  eff[1] = effort                               #effort at time t, here just a constant
  hr[1] = 1-exp(-(q*eff[1]))                #calculate harvest rate (U) and 1-exp(-F)
  yield[1] = hr[1]*VB [1]                   #first value of yield as hr * vulnerable biomass
  
  #shell and habitat stuff
  shell[1] = shell_init                     #defining shell as shell init. Note that Carl does have an equilibrium calc in his model, but not implemented here
  shell_add[1] = sum(nage[1,]*(1-Surv)*(TL/100)^2)    #the shell added in each year is a function of the numbers that didn't survive (i.e. nage*(1-surv)) and the lengths. this 
  #H[1] = 1                         #null assumption that 100% of area is suitable for recruitment. Can always start with this
  H_null[1] = 1                    #same initial assumptions for alternative habitat (each defined according to different assumptions about how shell translates to habitat for recruitment)
  H_lin[1] = 1
  H_thresh[1] = 1
  H_threshSafe[1] = 1
  
  #Need to select that habitat assumption. Dumb nested ifelse to choose habitat assumption...I can't think of a better way to do this now, but there probably is
  H[1] <- ifelse(habitat=="null", H_null[1], 
                 ifelse(habitat=="lin", H_lin[1],
                        ifelse(habitat=="thresh", H_thresh[1], H_threshSafe[1])
                 )
  )  
  
  ahab[1] = bha*H[1]*cstar         #habitat modified Beverton Holt a parm according to walters et al. 2007
  bhab[1] = H[1]^cstar*bhb/H[1]    #hab modified bev holt b parm according to same. note that cstar is a switch determining whether hab affects a or b
  
  #calculations for vectors--i.e. year but not age varying components of model
  for( i in 2:years) {
    #recruitment stuff
    shell[i] = shell[i-1]*shell_surv+shell_add[i-1]
    
    #Habitat-- These are the most important alternative assumptions of the model
    H_null[i] = 1        #this is the null assumption that habitat doesn't change. NOTE you could easily have a pre-determined habitat vector that could represent habitat loss or restoration
    H_lin[i] = shell[i]/shell_init       #this is a powerful assumption--that habitat for recruitment is directly related to shell. With fishing, this will collapse fishery. It essentially says oysters cannot be fished.
    H_thresh[i] = 1/(1+exp(-(shell[i]-sht)/shsd))   #simple logistic relationships between shell and habitat--i.e. above threshold amount of shell, habitat is good for recruitment. Below threshold level of shell, habitat for recruitment quickly delcines, even to zero. 
    #This most closely matches the assumption that oysters recruit on outside of a 3D reef, i.e. as reef heigh shrinks very little surface area is lost relative to reef 3D volume, until reef is too low to stay intact
    H_threshSafe[i] = pmax(0.1, 1/(1+exp(-(shell[i]-sht)/shsd)))   #This is a "safety net" function where we say look habitat can't be worse than 0.1 no matter what happens to shell. Basically it says oysters can recruit on the rock under the reef.
    
    #Making the habitat function selection, needed for the outer function
    H[i] <- ifelse(habitat=="null", H_null[i], 
                   ifelse(habitat=="lin", H_lin[i],
                          ifelse(habitat=="thresh", H_thresh[i], H_threshSafe[i])
                   )
    ) 
    #Operationalizing habitat (H) on recruitment parms
    ahab[i] = bha*H[i]*cstar         #habitat modified Beverton Holt a parm according to walters et al. 2007
    bhab[i] = H[i]^cstar*bhb/H[i]    #hab modified bev holt b parm according to same. note that cstar is a switch determining whether hab affects a or b
    #Recruitment, simple beverton holt
    nage[i,1] = ahab[i-1]*eggs[i-1]/(1+bhab[i-1]*eggs[i-1])*exp(proc_err[i-1])              #the recruitment each year, a product of beverton holt, eggs, and process error ****note this is going to be changed to be a function of a habitat dependent b parmameter, see DD habitat excel file
    
    #fishery stuff  
    eff[i] = effort   #constant effort, obv could be changed
    hr[i] = 1-exp(-q*eff[i])
    
    #Age loop  
    for(j in 2:amax)
    {
      nage[i,j] = nage[i-1,j-1]*Surv[j-1]*(1-Vul[j-1]*hr[i])               #this is the acutal population updating
    }
    
    shell_add[i] = sum(nage[i,]*(1-Surv)*(TL/100)^2)
    eggs[i] = sum(Fec*nage[i,])                                               #eggs in each year is simply the sum of numbers at age in that year * Fecundity
    N[i] = sum(nage[i,])                                                      #total numbers, sum of numbers at each age
    proc_err[i] = 0 #rnorm(1,0,sdpro)  #!!make equal to 0 for non-stochastic                   #the process error (realized through variation in recruitment) for each year
    B[i] = sum(nage[i,]*Wt)                                                   #total biomass, sum of numbers at age * weight at age
    VB[i] = sum(nage[i,]*Wt*Vul)                                              #vulernable biomass, sum of numbers at age * weight at age * vul at age
    yield[i] = hr[i]*VB [i]                                                   #yield, dependent on hr and vulnerable biomass
    
  }
  
  list (years=years, eggs = eggs, N=N, B=B, VB=VB,  yield = yield, obs_err = obs_err, proc_err = proc_err,
        shell=shell, shell_add=shell_add, eff=eff, hr=hr, ahab=ahab, bhab=bhab,
        H=H, H_null=H_null, H_lin=H_lin, H_thresh=H_thresh, H_threshSafe=H_threshSafe,      #H is the operational Habitat, each other are alternative assumptions that can be selected
        nage = nage)
  
}


################################################################################
### Output ###
################################################################################
### Model runs
null_lowEff = fun(effort=133, habitat="null")
thresh_lowEff = fun(effort=133, habitat="thresh")

null_hiEff = fun(effort=137, habitat="null")
thresh_hiEff = fun(effort=137, habitat="thresh")

### Plotting
#Plot showing alternative tipping points as function of habitat assumption (hysteresis implied)
par(mfrow=c(1,2))
plot(1:years, null_lowEff$nage[,1], type="l", col="lightblue", lwd=3, lty=1, main="", ylim=c(0,1100), ylab="Recruits", xlab="Timesteps (months)")
lines(1:years, thresh_lowEff$nage[,1], type="l", col="blue", lwd=3, lty=3)
legend("topright", legend=c("Rec.Hab. unerlated to shell", "Rec.Hab. threshold w.r.t shell"), col=c("lightblue", "blue"), lwd=c(3, 3), lty=c(1,3), bty="n")
mtext("Lesser effort (133 units/time)", outer=FALSE, cex=1.25, side=3, line=0, adj=0)
plot(1:years, null_hiEff$nage[,1], type="l", col="lightblue", lwd=3, lty=1, main="", ylim=c(0,1100), ylab="Recruits", xlab="Timesteps (months)")
lines(1:years, thresh_hiEff$nage[,1], type="l", col="blue", lwd=3, lty=3)
legend("topright", legend=c("Rec.Hab. unerlated to shell", "Rec.Hab. threshold w.r.t shell"), col=c("lightblue", "blue"), lwd=c(3, 3), lty=c(1,3), bty="n")
mtext("Greater effort (137 units/time)", outer=FALSE, cex=1.25, side=3, line=0, adj=0)
mtext("Recruitment", outer=TRUE, cex=2, side=3, line=-2)





