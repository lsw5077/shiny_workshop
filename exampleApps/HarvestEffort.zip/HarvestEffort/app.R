library(shiny)
library('leaflet')
library(raster)
library('sf')
library(rgdal)
source('updateFunctions.R')

introLbl = "Click the 'Begin' button to begin. Click on the 'Set Sanctuaries' button to set no-take zones. Click the 'Choose Harvest Area' button to set areas where you would like to harvest. Once your prefered parameters are set, click the 'Update' button to advance the simulation by 1 year. <br/> <br/>"
effortLbl = "<br/>What is the maximum number of hours that you are willing to spend harvesting each day?"
amountLbl = "What is the maximum number of sacks of oysters you would harvest in one day?"
sizeLbl = "Select a minimum size for legal harvest (inches)"
shellLbl="Check to require culling on site"
breakLbl="<br/>"

ui<-fluidPage(
  titlePanel("Oyster Harvest App"),
  
  sidebarLayout(position = "left",
    sidebarPanel(HTML(introLbl), actionButton(inputId="begin", label="Begin"),
                 numericInput(inputId="effort", label=HTML(effortLbl), value=8, min=1, max=16, step=1),
                 numericInput(inputId="amount", label=amountLbl, value=4, min=1, max=40, step=1),
                 numericInput(inputId="size", label=sizeLbl, value=3, min=1, max=6, step=1),
                 checkboxInput(inputId="shell", label=shellLbl, value = FALSE),
                 actionButton(inputId="update", label="Update")),
    mainPanel(textOutput("final"),
              textOutput("turns"),
              actionButton(inputId="sanctuaryMap", label="Set Sanctuaries"),
              actionButton(inputId="harvestMap", label="Choose Harvest Area"),
              leafletOutput("map"),
              plotOutput("history"),
              textOutput("time"),
              textOutput("sacks"),
              textOutput("size"),
              textOutput("longSacks"),
              textOutput("longTime"),
              textOutput("avgSize"),
              textOutput("avgTime"),
              textOutput("avgSacks"),))
)

server<-function(input, output, session){
  #Generate list of clickable coordinates
  cedKey <- readOGR(dsn=path.expand("shapefile"), layer="LC_10_Area") #Imports Cedar Key shape file
  ckCrd <- spTransform(cedKey, CRSobj = CRS("+init=epsg:4326")) #Converts shape file coordinate to longitude/latitude
  matCrd=expand.grid(x=seq(from=-83.1164,to=-83.06251,length.out=moveRow), #Generates a series of coordinates within range
                     y=seq(from=29.2169,to=29.26528,length.out=moveRow))
  df = data.frame(x = matCrd$x, y = matCrd$y)
  s = SpatialPixelsDataFrame(df[,c('x', 'y')], data = df, proj4string = crs(ckCrd))
  clp <- over(s[,c("x", "y")], ckCrd)
  cond <- !is.na(clp$Id)
  spNew<-s[cond,]
  spDf = as.data.frame(spNew)
  coord = data.frame(x=(trunc(df$x*1000)/1000), y=(trunc(df$y*1000)/1000))
  
  #Initialize oyster population variables
  nplts = 1600 #Total number of plots
  nsize = 7 #Number of size classes (including larva)
  myMaxDens = 1000 #The maximum capacity of every plot
  moveRow = sqrt(nplts) #The number of plots in a row
  
  #Set Reactive Population Variables
  reactivePop <- reactiveValues()
  reactivePop$oysters = 0
  reactivePop$myDens = 0
  reactivePop$myShell = 0
  reactivePop$heatVec = 0
  
  #Make Reactive Values (Sanctuary Map)
  myReactives <- reactiveValues()
  myReactives$offLim = 0
  myReactives$harvPlots = 0
  myReactives$showSanctuary = F
  myReactives$firstUpdate = T
  myReactives$lastPlot = 0
  
  #Make Harvest Output Reactive Values
  myOutputs <- reactiveValues()
  myOutputs$outHarvTime = 0
  myOutputs$outSacksTaken = 0
  myOutputs$outAvgSize = 0
  myOutputs$outTotAvgSize = 0
  myOutputs$outAvgTime = 0
  myOutputs$outAvgSacks = 0
  myOutputs$outLongTime = 0
  myOutputs$outLongSacks = 0
  myOutputs$turnCounter = 0
  myOutputs$finalScore = 0

  #React to click event
  observeEvent(input$map_marker_click, {
    click<-input$map_marker_click
    if(is.null(click))
      return()
    
    xClk=trunc(click$lng*1000)/1000
    yClk=trunc(click$lat*1000)/1000
    
    xCor = which(coord$x == xClk)
    yCor = which(coord$y == yClk)
    myPlot = intersect(xCor, yCor)
    myReactives$lastPlot = myPlot
    
    if(myReactives$showSanctuary == T){
      if(myReactives$offLim[myPlot]==1){
        myReactives$offLim[myPlot]=0
      }else if(myReactives$offLim[myPlot]==0){
        myReactives$offLim[myPlot]=1
      }
      myMap <- makeSanctuaryMap(myReactives$offLim)
      myOutputs$finalMap = myMap
    }
    else{
      if(myReactives$harvPlots[myPlot]==1){
        myReactives$harvPlots[myPlot]=0
      }else if(myReactives$harvPlots[myPlot]==0){
        myReactives$harvPlots[myPlot]=1
      }
      myMap <- makeHarvestMap(reactivePop$heatVec, myReactives$harvPlots, myReactives$offLim)
      myOutputs$finalMap = myMap
    }
  })
  
  observeEvent(input$begin,{
    #Make sanctuary variables. Needs to be reactive to be global
    myReactives$showSanctuary = F #Whether the Map Currently Displays Sanctuary Areas
    myReactives$offLim = vector(length=nplts) #1 if plot is a Sanctuary or 0 if not
    myReactives$offLim[] = 0
    myReactives$offLim[!cond]<-NA
    myReactives$lastPlot = 0
      
    myReactives$harvPlots = vector(length=nplts) #1 if plot is harvested by player or 0 if not
    myReactives$harvPlots[] = 0
    myReactives$harvPlots[!cond]<-NA
      
    myOutputs$turnCounter = 0
    myOutputs$finalScore = 0
    myOutputs$outAvgSize = 0
    myOutputs$outHarvTime = 0
    myOutputs$outSacksTaken = 0
    myOutputs$outTotAvgSize = 0
    myOutputs$outAvgTime = 0
    myOutputs$outAvgSacks = 0
    myOutputs$outLongTime = 0
    myOutputs$outLongSacks = 0
    myOutputs$finalMap = myMap
      
    reactivePop$oysters = matrix(0, nplts,nsize)
    reactivePop$myDens = vector(length=nplts) #Total number of oysters weighted by size
    reactivePop$myShell = vector(length=nplts) #The amount of dead shell (or other non-living hard substrate)
    reactivePop$heatVec = vector(length=nplts)
      
    #Initialize oyster population with randomization
    for(i in 1:nplts){
      initMin = c(20,20,5,5,0,0) #Minimum number of oysters of each size at game start
      initMax = c(60,40,30,20,10,5) #Maximum number of oysters of each size at game start
      reactivePop$oysters[i,1:6]=runif(6, initMin, initMax)
      reactivePop$oysters[i,7]=sum(reactivePop$oysters[i,1:6]*4)
    }
    reactivePop$oysters[!cond,]<-NA
    for(i in 1:nplts){
      reactivePop$myDens[i]=sum(reactivePop$oysters[i,1:6]*c(1:6))
      reactivePop$myShell[i]=0.2*reactivePop$myDens[i]
    }
      
    #Set values of outputs before initial update
    for(i in 1:nplts){
      reactivePop$heatVec[i] = (100*reactivePop$myDens[i])/myMaxDens
    }
    myMap = makeHarvestMap(reactivePop$heatVec, myReactives$harvPlots, myReactives$offLim)
  })
  observeEvent(input$update,{
    myOutputs$turnCounter = myOutputs$turnCounter + 1
    myHarvLim = input$amount
    myMaxTime = input$effort
    myMinSize = input$size
    myPlots = myReactives$lastPlot #NEEDS CHANGING
    returnShells = input$shell
    param = c(myHarvLim, myMaxTime, myMinSize, myPlots, returnShells)
    
    newOysters = reactivePop$oysters
    newDens = reactivePop$myDens
    newShell = reactivePop$myShell
    
    outVar<-localUpdate(param, newOysters, myMaxDens, newDens, newShell, nplts)
    
    #Determine average reef density
    meanDens <- 0
    densLength <- 0
    for(i in 1:length(reactivePop$heatVec)){
      if(is.na(reactivePop$heatVec[i])==F){
        densLength <- densLength + 1
        meanDens <- meanDens + reactivePop$heatVec[i]
      }
    }
    meanDens <- meanDens/densLength
    
    #Update Global Outputs
    myOutputs$outAvgSize = outVar$avgSize
    myOutputs$outHarvTime = outVar$harvTime
    myOutputs$outSacksTaken = outVar$sacksTaken
    myOutputs$finalMap = outVar$myMap
    myReactives$showSanctuary = T
    
    #Update Longterm Outputs/Averages
    myOutputs$outLongTime = myOutputs$outLongTime + outVar$harvTime
    myOutputs$outLongSacks = myOutputs$outLongSacks + outVar$sacksTaken
    myOutputs$outTotAvgSize = ((myOutputs$outTotAvgSize*myOutputs$turnCounter)+outVar$avgSize)/(myOutputs$turnCounter+1)
    myOutputs$outAvgTime = ((myOutputs$outAvgTime*myOutputs$turnCounter)+outVar$harvTime)/(myOutputs$turnCounter+1)
    myOutputs$outAvgSacks = ((myOutputs$outAvgSacks*myOutputs$turnCounter)+outVar$sacksTaken)/(myOutputs$turnCounter+1)
    
    myOutputs$finalScore[myOutputs$turnCounter] = ((myOutputs$outLongSacks / myOutputs$turnCounter)*
                              (meanDens)/100)
  })
  
  observeEvent(input$sanctuaryMap,{
    if(myReactives$showSanctuary == T)
      return()
    print(myReactives$showSanctuary)
    myReactives$showSanctuary = T
    myMap <- makeSanctuaryMap(myReactives$offLim)
    myOutputs$finalMap = myMap
  })
  
  observeEvent(input$harvestMap,{
    if(myReactives$showSanctuary == F)
      return()
    print(myReactives$showSanctuary)
    myReactives$showSanctuary = F
    myMap <- makeHarvestMap(reactivePop$heatVec, myReactives$harvPlots, myReactives$offLim)
    myOutputs$finalMap = myMap
  })
  
  localUpdate <- function(param, locOyster, myMaxDens, locDens, locShell, nplts){
    myUpdate<-updateFunction(locOyster, myMaxDens, locDens, locShell, param, nplts) #All updates done in separate script
    
    #Set oyster pop, dens, and dead shell according to updates
    reactivePop$oysters =  myUpdate$oysters
    for(i in 1:nplts){
      reactivePop$myDens[i] = sum(reactivePop$oysters[i,1:6]*c(1:6))
    }
    reactivePop$myShell = myUpdate$shell
    
    #Calculate heatmap values based on density (biomass)
    for(i in 1:nplts){
      reactivePop$heatVec[i] = (100*reactivePop$myDens[i])/myMaxDens
    }
    myMap <- makeHarvestMap(reactivePop$heatVec, myReactives$harvPlots, myReactives$offLim, needNPC = T) #Create Map
    
    return(list(avgSize = myUpdate$avgSize, harvTime = myUpdate$harvTime, sacksTaken = myUpdate$sacksTaken, 
                myMap = myMap, myShell = myShell, myDens = myDens, oysters = reactivePop$oysters))
  }
  
  #Assemble and Display Outputs
  output$final <- renderText({
    input$update
    timeString <- isolate(c("Overall Score: ", toString(trunc(myOutputs$finalScore[length(myOutputs$finalScore)]*100)/100)))
    timeString})
  
  output$turns <- renderText({
    input$update
    timeString <- isolate(c("Number of Turns Remaining: ", 50-myOutputs$turnCounter))
    timeString})
  
  output$history <- renderPlot({
    input$update
    x <- c(1:length(myOutputs$finalScore))
    y <- myOutputs$finalScore
    plot(x=x, y=y, type = "l", lwd=2, xlab = "Turns Since Game Start", ylab = "Overall Score at Turn",
         main="Overall Score Over Time", xlim = c(0,50), ylim = c(0,15))
    })
  
  output$map <- renderLeaflet({
    input$map_marker_click #Makes output dependent on map or button click (via isolate)
    input$sanctuaryMap
    input$harvestMap
    input$update
    input$begin
    isolate(myOutputs$finalMap)})
  
  output$time <- renderText({
    input$update
    timeString <- isolate(c("Time Spent Harvesting Each Day: ", 
                            toString(trunc(myOutputs$outHarvTime*100)/100), " hours"))
    timeString})
  
  output$sacks <- renderText({
    input$update
    sacksString<-isolate(c("Average Number of Sacks Harvested per Day: ", 
                           toString(trunc(myOutputs$outSacksTaken*100)/100), " sacks"))
    sacksString})
  
  output$size <- renderText({
    input$update
    sizeString<-isolate(c("Average Size of Harvested Oysters this Year: ", 
      toString(trunc(myOutputs$outAvgSize*100)/100), " inches"))
    sizeString})
  
  output$avgTime <- renderText({
    input$update
    longSacksString<-isolate(c("All-time average number of hours spent harvesting each day: ", 
                               toString(trunc(myOutputs$outAvgTime*100)/100), " hours"))
    longSacksString})
  
  output$avgSacks <- renderText({
    input$update
    longSacksString<-isolate(c("All-time average number of sacks harvested: ", 
                               toString(trunc(myOutputs$outAvgSacks*100)/100), " sacks"))
    longSacksString})
  
  output$avgSize <- renderText({
    input$update
    longSacksString<-isolate(c("All-time average size of harvested oysters: ", 
                               toString(trunc(myOutputs$outTotAvgSize*100)/100), " inches"))
    longSacksString})
  
  output$longSacks <- renderText({
    input$update
    longSacksString<-isolate(c("Total number of sacks harvested (all-time): ", 
                          toString(trunc(myOutputs$outLongSacks*100)/100), " sacks"))
    longSacksString})
}

shinyApp(ui = ui, server = server)