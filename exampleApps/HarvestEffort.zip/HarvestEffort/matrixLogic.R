library('leaflet')
library(raster)

nplts = 225
nsize = 7
oysters = matrix(0, nplts,nsize)
myDens = vector(length=nplts)
myShell = vector(length=nplts)
myMaxDens = 1000
moveRow = sqrt(nplts)

for(i in 1:nplts){
  initMin = c(20,20,5,5,0,0)
  initMax = c(60,40,30,20,10,5)
  oysters[i,1:6]=runif(6, initMin, initMax)
  oysters[i,7]=sum(oysters[i,1:6]*4)
  
  myDens[i]=sum(oysters[i,1:6]*c(1:6))
  myShell[i]=0.2*myDens[i]
}

harvest<-function(x, maxDens, dens, deadShell, theta){
  harvLim = theta[1]
  maxTime = theta[2]
  minSize = theta[3]
  harvPlot = theta[4]
  returnShells = theta[5]
  deadShell = deadShell
  
  sacksTaken = 0
  totalTake = 0
  harvTime = 0
  shellDecay = 0.2
  totalCaught = 0
  avgSize = 0
  decHarv = 500
  harvFac = 0.8
  shellHarvFac = 0.5
  shellsReturned = 0
  movePlot=vector(length=5)
  moveIndex=c(0,1,-1,moveRow,-moveRow)
  kMax = 1
  moveMax = 0
  
  survAdult = 0.43
  survJuv = 0.001
  birthRate = 2
  overflow = 0.2
  prodCap = decHarv
  if(decHarv>dens[harvPlot])  prodCap=dens[harvPlot]
  
  if(returnShells == T){
    harvFac = shellHarvFac
    shellsReturned = 1
  }
  
  for(i in 1:maxTime){
    dens[i]=sum(x[i,1:6]*c(1:6))
    if(totalTake < harvLim){
      sacksTaken = 0
      sacksTaken = sacksTaken + prodCap*harvFac
      deadShell[harvPlot] = deadShell[harvPlot] + 
        (sum(x[harvPlot,1:6]*c(1:6))*harvFac*shellsReturned) #Probably will be removed
      
      sizeSeq = minSize:6
      xCaught = x[harvPlot,sizeSeq]*harvFac
      avgSize= avgSize + sum(xCaught*sizeSeq)
      totalCaught=totalCaught + sum(xCaught)
      x[harvPlot, sizeSeq] = x[harvPlot, sizeSeq] - xCaught
      
      harvTime = harvTime + 1
      dens[i]=sum(x[i,1:6]*c(1:6))
    }
    movePlot=vector(length=5)
    moveIndex=c(0,1,-1,moveRow,-moveRow)
    kMax = 1
    moveMax = 0
    movePlot[1]=dens[harvPlot]
    if((harvPlot-1)%%moveRow != 0){
      movePlot[2] = dens[harvPlot+1]
    }
    if(harvPlot%%moveRow != 0){
      movePlot[3] = dens[harvPlot-1]
    }
    if(harvPlot<nplts-moveRow){
      movePlot[4] = dens[harvPlot+moveRow]
    }
    if(harvPlot>moveRow){
      movePlot[5] = dens[harvPlot-moveRow]
    }
    moveMax=dens[harvPlot]
    for(k in 2:5){
      if(movePlot[k]>moveMax){
        moveMax=movePlot[k]
        kMax = k
      }
    }
    harvPlot = harvPlot + moveIndex[kMax]
    
    sacksTaken = sacksTaken/100
    totalTake = totalTake+sacksTaken
  }
  avgSize = avgSize/totalCaught
  
  openSpace = T
  for(h in 1:nplts){
    popCap = dens[h] + deadShell[h]
    openSpace = T
    if(dens[h]>maxDens){
      openSpace = F
    }
    popCap = dens[h] + deadShell[h]
    if(popCap > maxDens){
      popCap = maxDens
    }
    deadShell[h]=deadShell[h]*0.5
    for(i in 1:6){
      if(openSpace == T){
        if(i==1){
          x[h, 7-i] = (x[h, 7-i] + x[h, (7-i)-1])*survAdult
          deadShell[h] = deadShell[h] + (x[h, 7-i] + x[h, (7-i)-1])*(1-survAdult)
        }
        else if(i==6){
          x[h,7-i] = x[h, 7] * survJuv * popCap
        }
        else{
          x[h, 7-i] = x[h, (7-i)-1] * survAdult
          deadShell[h] = x[h, (7-i)-1]*(1-survAdult)
        }
      }
      dens[h]=sum(x[h,1:6]*c(1:6))
      if(dens[h]>maxDens)
        openSpace = F
    }
    x[h,7]=sum(x[h,1:6]*birthRate)
    if(h>1){
      if(dens[h-1]>=maxDens){
        x[h,7]=x[h,7]+sum(sum(x[h-1,1:6]*overflow))
      }
    }
    if(h<nplts){
      if(dens[h+1]>=maxDens){
        x[h,7]=x[h,7]+sum(sum(x[h+1,1:6]*overflow))
      }
    }
    if(h>moveRow){
      if(dens[h-moveRow]>=maxDens){
        x[h,7]=x[h,7]+sum(sum(x[h-moveRow,1:6]*overflow))
      }
    }
    if(h<(nplts-moveRow)){
      if(dens[h+moveRow]>=maxDens){
        x[h,7]=x[h,7]+sum(sum(x[h+moveRow,1:6]*overflow))
      }
    }
  }
  
  x[x<0] = 0
  
  return(list(oysters=x, shell=deadShell, avgSize=avgSize, harvTime=harvTime, sacksTaken=totalTake))
}

updateMap<-function(heatCol){
  combo=expand.grid(x=seq(from=-83,to=-83.07,length.out=moveRow),
                    y=seq(from=29.11,to=29.17,length.out=moveRow))
  df = data.frame(value = heatVec, lng = combo$x, lat = combo$y)
  s = SpatialPixelsDataFrame(df[,c('lng', 'lat')], data = df)
  crs(s) = sp::CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
  r = raster(s)
  val = as.numeric(c(0:100))
  pal = colorNumeric(c("red", "purple", "blue"), c(0,100),
                     na.color = "black")
  showMap = leaflet() %>% addTiles()  %>%
    addRasterImage(r, colors = pal, opacity = 0.5) %>%
    addLegend(pal = pal, values = c(0,100), title = "Reef Health")
  
  return(showMap)
}

myHarvLim = 30
myMaxTime = 8
mySizeLim = 3
myHarvPlot = 115
doReturnShells = F
param = c(myHarvLim, myMaxTime, mySizeLim, myHarvPlot, doReturnShells)

update<-harvest(oysters, myMaxDens, myDens, myShell, param)
oysters = update$oysters
for(i in 1:nplts){
  myDens[i] = sum(oysters[i,1:6]*c(1:6))
}
myShell = update$shell

heatVec = vector(length=nplts)
for(i in 1:nplts){
  heatVec[i] = (100*myDens[i])/myMaxDens
}

myMap = updateMap(heatVec)
myMap
update