library(shiny)
library('leaflet')
library(raster)
library('sf')
library(rgdal)
source('updateFunctions.R')

ui<-fluidPage(
  actionButton(inputId="update", label="Begin"),
  actionButton(inputId="sanctuaryMap", label="Set Sanctuaries"),
  actionButton(inputId="harvestMap", label="Choose Harvest Area"),
  leafletOutput("map")
)

server<-function(input, output, session){
  #Generate list of clickable coordinates
  cedKey <- readOGR(dsn=path.expand("shapefile"), layer="LC_10_Area") #Imports Cedar Key shape file
  ckCrd <- spTransform(cedKey, CRSobj = CRS("+init=epsg:4326")) #Converts shape file coordinate to longitude/latitude
  matCrd=expand.grid(x=seq(from=-83.1164,to=-83.06251,length.out=moveRow), #Generates a series of coordinates within range
                     y=seq(from=29.2169,to=29.26528,length.out=moveRow))
  df = data.frame(x = matCrd$x, y = matCrd$y)
  s = SpatialPixelsDataFrame(df[,c('x', 'y')], data = df, proj4string = crs(ckCrd))
  clp <- over(s[,c("x", "y")], ckCrd)
  cond <- !is.na(clp$Id)
  spNew<-s[cond,]
  spDf = as.data.frame(spNew)
  coord = data.frame(x=(trunc(df$x*1000)/1000), y=(trunc(df$y*1000)/1000))
  
  nplts = 1600 #Total number of plots
  heatVec = vector(length=nplts)
  for(i in 1:nplts){
    heatVec[i] = sample(1:100, 1)
  }
  myMap = updateMap(heatVec)
}