Shapefiles used in the Interactive Map. 
