library('leaflet')
library(raster)
library('sf')
library(rgdal)
source('updateFunctions.R')
library('foreign')

read.dbf("shapefile/LC_10_Area.dbf")

cedKey <- readOGR(dsn=path.expand("shapefile"), layer="LC_10_Area")
ckCrd <- spTransform(cedKey, CRSobj = CRS("+init=epsg:4326"))
plot(ckCrd)

#Initialize oyster population variables
nplts = 225 #Total number of plots
nsize = 7 #Number of size classes (including larva)
oysters = matrix(0, nplts,nsize)
myDens = vector(length=nplts) #Total number of oysters weighted by size
myShell = vector(length=nplts) #The amount of dead shell (or other non-living hard substrate)
myMaxDens = 1000 #The maximum capacity of every plot
moveRow = sqrt(nplts) #The number of plots in a row

#Initialize oyster population with randomization
for(i in 1:nplts){
  initMin = c(20,20,5,5,0,0) #Minimum number of oysters of each size at game start
  initMax = c(60,40,30,20,10,5) #Maximum number of oysters of each size at game start
  oysters[i,1:6]=runif(6, initMin, initMax)
  oysters[i,7]=sum(oysters[i,1:6]*4)
  
  myDens[i]=sum(oysters[i,1:6]*c(1:6))
  myShell[i]=0.2*myDens[i]
}

#User set variables
myHarvLim = 30 #Maximum number of sacks to harvest each day
myMaxTime = 8 #Maximum amount of time to harvest each day (hours)
mySizeLim = 3 #Minimum size of legal oyster (inches)
myHarvPlot = 115 #Plot number to begin harvest
doReturnShells = F #True if oyster shells are returned to fished location
param = c(myHarvLim, myMaxTime, mySizeLim, myHarvPlot, doReturnShells)

update<-updateFunction(oysters, myMaxDens, myDens, myShell, param, nplts) #All updates done in separate script

#Set oyster pop, dens, and dead shell according to updates
oysters = update$oysters
for(i in 1:nplts){
  myDens[i] = sum(oysters[i,1:6]*c(1:6))
}
myShell = update$shell

#Calculate heatmap values based on density (biomass)
heatVec = vector(length=nplts)
for(i in 1:nplts){
  heatVec[i] = (100*myDens[i])/myMaxDens
}

myMap = updateMap(heatVec) #Create Map

#Display user outputs
myMap
update$avgSize
update$harvTime
update$sacksTaken