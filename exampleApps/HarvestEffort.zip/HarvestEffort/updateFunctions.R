#Functions Used During Update
library('leaflet')
library(raster)
library('sf')
library(rgdal)

updateFunction<-function(x, maxDens, dens, deadShell, theta, nplts){ #To be performed when 'Update' button is clicked
  #x used to indicate oysters throughout this script
  newHarvest<-updateHarvest(x, maxDens, dens, deadShell, theta, nplts)
  x=newHarvest$x
  dens=newHarvest$dens
  deadShell=newHarvest$deadShell
  avgSize=newHarvest$avgSize
  harvTime=newHarvest$harvTime
  totalTake=newHarvest$totalTake
  
  newPop<-updatePopulation(x, dens, maxDens, deadShell, nplts)
  x=newPop$x
  dens=newPop$dens
  deadShell=newPop$deadShell
  
  return(list(oysters=x, shell=deadShell, avgSize=avgSize, harvTime=harvTime, sacksTaken=totalTake))
}

updateMap<-function(heatVec){ #Creates heatmap from vector
  cedKey <- readOGR(dsn=path.expand("shapefile"), layer="LC_10_Area") #Imports Cedar Key shape file
  ckCrd <- spTransform(cedKey, CRSobj = CRS("+init=epsg:4326")) #Converts shape file coordinate to longitude/latitude
  matCrd=expand.grid(x=seq(from=-83.1164,to=-83.06251,length.out=moveRow), #Generates a series of coordinates within range
                     y=seq(from=29.2169,to=29.26528,length.out=moveRow))
  df = data.frame(value = heatVec, x = matCrd$x, y = matCrd$y) #Generates Data Frame of population and coordinates
  s = SpatialPixelsDataFrame(df[,c('x', 'y')], data = df, proj4string = crs(ckCrd))
  clp <- over(s[,c("x", "y")], ckCrd)
  cond <- !is.na(clp$Id)
  spNew<-s[cond,]
  for(i in 1:length(spNew)){
    if(spNew$value[i]>100){
      spNew$value[i] = 100
    }
  }
  r = raster(spNew)
  pal = colorNumeric(c("red", "yellow", "green"), c(0,100),
                     na.color = "transparent")
  showMap = leaflet() %>% addTiles()  %>%
    addRasterImage(r, colors = pal, opacity = 1) %>%
    addLegend(pal = pal, values = c(0,100), title = "Oyster Density") %>%
    addCircleMarkers(lng= spNew$x, lat = spNew$y, label = round(spNew$value, digits = 0),
                     radius = 9, color = pal, fillOpacity = 0, labelOptions = labelOptions(textsize = "20px"))
  
  return(showMap)
}

makeSanctuaryMap<-function(offLim){ #Creates heatmap from vector
  cedKey <- readOGR(dsn=path.expand("shapefile"), layer="LC_10_Area") #Imports Cedar Key shape file
  ckCrd <- spTransform(cedKey, CRSobj = CRS("+init=epsg:4326")) #Converts shape file coordinate to longitude/latitude
  matCrd=expand.grid(x=seq(from=-83.1164,to=-83.06251,length.out=moveRow), #Generates a series of coordinates within range
                     y=seq(from=29.2169,to=29.26528,length.out=moveRow))
  df = data.frame(value = offLim, x = matCrd$x, y = matCrd$y) #Generates Data Frame of population and coordinates
  s = SpatialPixelsDataFrame(df[,c('x', 'y')], data = df, proj4string = crs(ckCrd))
  clp <- over(s[,c("x", "y")], ckCrd)
  cond <- !is.na(clp$Id)
  spNew<-s[cond,]
  r = raster(spNew)
  pal = colorNumeric(c("green3", "black"), c(0,1),
                     na.color = "transparent")
  showMap = leaflet() %>% addTiles()  %>%
    addRasterImage(r, colors = pal, opacity = 1) %>%
    addLegend(colors =c("green", "black"), labels= c("Open", "No-take"), 
              title = "Oyster Sanctuaries", opacity = 1) %>%
    addCircleMarkers(lng= spNew$x, lat = spNew$y, radius = 9, color = pal, fillOpacity = 0)
  
  return(showMap)
}

makeHarvestMap<-function(heatVec, pickedPlots, offLim, needNPC = F){ #Creates heatmap from vector
  npc <- makeIcon("boat2.png", 20, 20, iconAnchorX = 10, iconAnchorY = 10) #Add icons
  closure <- makeIcon("closed2.png", 20, 20, iconAnchorX = 10, iconAnchorY = 10)
  cedKey <- readOGR(dsn=path.expand("shapefile"), layer="LC_10_Area") #Imports Cedar Key shape file
  ckCrd <- spTransform(cedKey, CRSobj = CRS("+init=epsg:4326")) #Converts shape file coordinate to longitude/latitude
  matCrd=expand.grid(x=seq(from=-83.1164,to=-83.06251,length.out=moveRow), #Generates a series of coordinates within range
                     y=seq(from=29.2169,to=29.26528,length.out=moveRow))
  df = data.frame(value = heatVec, lblVal = heatVec, overlay = pickedPlots, sanc = offLim, hasNPC = 0, x = matCrd$x, y = matCrd$y) #Generates Data Frame of population and coordinates
  s = SpatialPixelsDataFrame(df[,c('x', 'y')], data = df, proj4string = crs(ckCrd))
  clp <- over(s[,c("x", "y")], ckCrd)
  cond <- !is.na(clp$Id)
  spNew<-s[cond,]
  
  for(i in 1:length(spNew$value)){
    if(spNew$value[i]>=100){
      spNew$value[i]=100
      spNew$lblVal[i]=100
    }
    if(spNew$overlay[i]==1){
      spNew$value[i]=132
    }
    if(needNPC == T){
      if(runif(1, min=0, max=100)>=85){
        spNew$hasNPC[i] = 1
      }
    }
  }
  
  spSanc<-spNew[spNew$sanc==1,]
  spNPC<-spNew[spNew$hasNPC==1,]
  r = raster(spNew)
  pal = colorNumeric(c("red", "yellow", "green", "black"), c(0,132),
                     na.color = "transparent")
  
  showMap = leaflet() %>% addTiles()  %>%
    addRasterImage(r, colors = pal, opacity = 1) %>%
    addLegend(pal = pal, values = c(0,100), title = "Oyster Density") %>%
    addCircleMarkers(lng= spNew$x, lat = spNew$y, label = round(spNew$lblVal, digits = 0),
                     radius = 9, color = pal, fillOpacity = 0, labelOptions = labelOptions(textsize = "20px")) %>%
    addMarkers(icon=closure, lng= spSanc$x, lat = spSanc$y, 
               label = round(spNew$lblVal, digits = 0), labelOptions = labelOptions(textsize = "20px")) %>%
    addMarkers(icon=npc, lng= spNPC$x, lat = spNPC$y, 
               label = round(spNew$lblVal, digits = 0), labelOptions = labelOptions(textsize = "20px"))
    
  
  return(showMap)
}

overlayColor<-function(heatVec, pickedPlots){
  color = NA
  if(pickedPlots == 1){
    color = "black"
  }else {
    color = pal()
  }
  return(color)
}
  

updateHarvest<-function(x, maxDens, dens, deadShell, theta, nplts){ #All harvest related calculations
  harvLim = theta[1]
  maxTime = theta[2]
  minSize = theta[3]
  harvPlot = theta[4]
  returnShells = theta[5]
  
  #Initialize Harvest Related Variables
  sacksTaken = 0
  totalTake = 0
  harvTime = 0
  totalCaught = 0
  avgSize = 0
  decHarv = 500 #Threshold for declining CPUE
  harvFac = 0.8 #The percentage of oysters in each plot that can be harvested in an hour
  shellHarvFac = 0.5 #Modified harvFac if shells are returned
  shellsReturned = 0 #1 if shells are returned
  
  #Determine if density is above CPUE threshold and set variables accordingly
  prodCap = decHarv
  if(decHarv>dens[harvPlot])  prodCap=dens[harvPlot]
  
  #Determine whether shells are returned and set variables accordingly
  if(returnShells == T){
    harvFac = shellHarvFac
    shellsReturned = 1
  }
  
  for(i in 1:maxTime){ #Iterates for every hour of harvest
    dens[i]=sum(x[i,1:6]*c(1:6))
    if(totalTake < harvLim){ #Exits if bag limit has been reached
      sacksTaken = 0 #Only counts sacks taken this hour, will be added to total take later
      sacksTaken = sacksTaken + prodCap*harvFac #Adds caught oysters to catch
      deadShell[harvPlot] = deadShell[harvPlot] + 
        (sum(x[harvPlot,1:6]*c(1:6))*harvFac*shellsReturned) #Adds caught oysters to dead shell if shells are returned
      
      #Remove caught oysters from oyster population
      sizeSeq = minSize:6
      xCaught = x[harvPlot,sizeSeq]*harvFac
      avgSize= avgSize + sum(xCaught*sizeSeq) #Total number of oysters weighted by size, will be divided by totalCaught later
      totalCaught=totalCaught + sum(xCaught) #Total number of oysters caught
      x[harvPlot, sizeSeq] = x[harvPlot, sizeSeq] - xCaught
      dens[i]=sum(x[i,1:6]*c(1:6))
      
      harvTime = harvTime + 1
    }
    harvPlot=checkAdjacentPlots(harvPlot, dens, nplts)
    
    sacksTaken = sacksTaken/100 #Needed to make values realistic
    totalTake = totalTake+sacksTaken #Catch across all hours
  }
  avgSize = avgSize/totalCaught #Converts to average size of a single caught oyster
  return(list(x=x, dens=dens, deadShell=deadShell, avgSize=avgSize, harvTime=harvTime, totalTake=totalTake))
}

checkAdjacentPlots<-function(harvPlot, dens, nplts){ #Check density of adjacent plots and move to plot with greatest density
  moveRow = sqrt(nplts) #Number of squares in a row
  movePlot=vector(length=5) #To be stored with values of current and neighboring plot. Current, Left, Right, Up, Down
  moveIndex=c(0,1,-1,moveRow,-moveRow) #Movement needed to get from current plot to movePlot
  kMax = 1 #Index of greatest value in movePlot
  moveMax = 0
  
  movePlot[1]=dens[harvPlot]
  #Makes sure current plot is not on an edge before allowing movement
  if((harvPlot-1)%%moveRow != 0){ #Right Edge
    if(!is.na(dens[harvPlot+1])){
      movePlot[2] = dens[harvPlot+1]
    }
  }
  if(harvPlot%%moveRow != 0){ #Left Edge
    if(!is.na(dens[harvPlot-1])){
      movePlot[3] = dens[harvPlot-1]
    }
  }
  if(harvPlot<nplts-moveRow){ #Bottom Edge
    if(!is.na(dens[harvPlot+moveRow])){
      movePlot[4] = dens[harvPlot+moveRow]
    }
  }
  if(harvPlot>moveRow){ #Top Edge
    if(!is.na(dens[harvPlot-moveRow])){
      movePlot[5] = dens[harvPlot-moveRow]
    }
  }
  
  moveMax=dens[harvPlot] #Sets default max to current plot
  for(k in 2:5){ #Checks if neighboring plots have greater density and adjusts kMax accordingly
    if(movePlot[k]>moveMax){
      moveMax=movePlot[k]
      kMax = k
    }
  }
  harvPlot = harvPlot + moveIndex[kMax] #Moves current plot to maximum adjacent (if any)
  return(harvPlot)
}

updatePopulation<-function(x, dens, maxDens, deadShell, nplts){
  survAdult = 0.55
  survJuv = 0.003
  shellDecay = 0.2 #Percentage of shells that decay each year
  openSpace = T #Whether or not population is at population threshold
  #Population will increase linearly unless population is at threshold at which point recruitment declines to 0
  
  for(h in 1:nplts){
    if(!is.na(x[h,1])){
      popCap = dens[h] + deadShell[h]
      openSpace = T
      if(dens[h]>maxDens){ #Checks if plot population is at population threshold
        openSpace = F
      }
      popCap = dens[h] + deadShell[h] #Sets room for new recruitment
      if(popCap > maxDens){
        popCap = maxDens
      }
      deadShell[h]=deadShell[h]*shellDecay
    
      #Update population and add dead shell from natural mortality
      for(i in 1:6){
        if(openSpace == T){
          if(i==1){ #Population update for maximum size oysters, recruitment from lower size and from previous
            x[h, 6] = (x[h, 6] + x[h, 5])*survAdult
            deadShell[h] = deadShell[h] + ((x[h, 6] + x[h, 5])*(1-survAdult))
          }else if(i==6){ #Update larva into size 1 oysters (No dead shell from natural mortality of larva)
            x[h,7-i] = x[h, 7] * survJuv * popCap
          }
          else{ #All other size classes (recruitment from lower size, no chance of remaining in current size)
            x[h, 7-i] = x[h, (7-i)-1] * survAdult
            deadShell[h] = deadShell[h] + x[h, (7-i)-1]*(1-survAdult)
          }
        }
        dens[h]=sum(x[h,1:6]*c(1:6)) #Update density accordingly will stop updating population as soon as density has reached maximum
        if(dens[h]>maxDens)
          openSpace = F
      }
    }
  }
  larva=calcLarva(x, h, dens, maxDens, nplts)
  x=larva$x
  dens=larva$dens
  
  x[x<0] = 0
  return(list(x=x, dens=dens, deadShell=deadShell))
}

calcLarva<-function(x, h, dens, maxDens, nplts){ #Determine the number of larva in each plot x[7]
  moveRow = sqrt(nplts)
  for(h in 1:nplts){
    if(!is.na(x[h,7])){
      birthRate = 2 #Number of births per all non-larva oysters
      overflow = 0.2 #Number of larva dispersed into nearby plots from each non-larva oyster (only if plot is at max density)
      x[h,7]=sum(x[h,1:6]*birthRate) #Add larva from oysters in current plot
    
      #Determines if plot is on edge, and adds dispersal from neighboring plot if neighboring plot is at maximum density
      if((h-1)%%moveRow != 0){
        if(!is.na(dens[h-1])){
          if(dens[h-1]>=maxDens){
            x[h,7]=x[h,7]+sum(sum(x[h-1,1:6]*overflow))
          }
        }  
      }
      if(h%%moveRow != 0){
        if(!is.na(dens[h+1])){
          if(dens[h+1]>=maxDens){
            x[h,7]=x[h,7]+sum(sum(x[h+1,1:6]*overflow))
          }
        }  
      }
      if(h>moveRow){
        if(!is.na(dens[h-moveRow])){
          if(dens[h-moveRow]>=maxDens){
            x[h,7]=x[h,7]+sum(sum(x[h-moveRow,1:6]*overflow))
          }
        }
      }
      if(h<(nplts-moveRow)){
        if(!is.na(dens[h+moveRow])){
          if(dens[h+moveRow]>=maxDens){
            x[h,7]=x[h,7]+sum(sum(x[h+moveRow,1:6]*overflow))
          }
        }
      }
    }
  }
  return(list(x=x, dens=dens))
}