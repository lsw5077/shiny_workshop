nplts = 150
dens=vector(length=nplts)
maxDens=0
spat=vector(length=nplts)
size1=vector(length=nplts)
size2=vector(length=nplts)
size3=vector(length=nplts)
size4=vector(length=nplts)
size5=vector(length=nplts)
size6=vector(length=nplts)
deadShell=vector(length=nplts)

#Initialize Population
for(i in 1:nplts){
  size6[i]=10000
  size5[i]=40000
  size4[i]=40000
  size3[i]=200000
  size2[i]=700000
  size1[i]=1000000
  spat[i]=size1[i]*300+size2[i]*300+size3[i]*300+size4[i]*300+size5[i]*300+size6[i]*300
  dens[i]=size1[i]*1+size2[i]*2+size3[i]*3+size4[i]*4+size5[i]*5+size6[i]*6
  deadShell[i]=dens[i]*0.2
}
maxDens = dens[1]*2

harvest<-function(sp, c1, c2, c3, c4, c5, c6, d, ds, theta){
  sp=sp
  c1=c1
  c2=c2
  c3=c3
  c4=c4
  c5=c5
  c6=c6
  d=d
  ds=ds
  sj=0.006
  sa=0.7
  md = theta[1]
  hl = theta[2]
  mt = theta[3]
  sl = theta[4]
  hp = theta[5]
  rs = theta[6]
  gathered = 0
  weight = 0
  sacksTaken = 0
  harvTime = 0
  shellDecay = 0.6
  totalCaught = 0
  avgSize = 0
  
  for(i in 1:mt){
    gathered = 0
    
    if(sacksTaken < hl){
      if(rs==1){
        if(sl<=1){
          gathered = gathered + c1[hp]*0.03
          ds[hp] = c1[hp]*0.025
          c1[hp] = c1[hp] - c1[hp]*0.03
          totalCaught = c1[hp]*0.03
          avgSize = c1[hp]*0.03}
        if(sl<=2){
          gathered = gathered + 2*c2[hp]*0.03
          ds[hp] = c2[hp]*0.025
          c2[hp] = c2[hp] - c2[hp]*0.03
          totalCaught = c2[hp]*0.03
          avgSize = c2[hp]*0.03*2}
        if(sl<=3){
          gathered = gathered + 3*c3[hp]*0.03
          ds[hp] = c3[hp]*0.025
          c3[hp] = c3[hp] - c3[hp]*0.03
          totalCaught = c3[hp]*0.03
          avgSize = c3[hp]*0.03*3}
        if(sl<=4){
          gathered = gathered + 4*c4[hp]*0.03
          ds[hp] = c4[hp]*0.025
          c4[hp] = c4[hp] - c4[hp]*0.03
          totalCaught = c4[hp]*0.03
          avgSize = c4[hp]*0.03*4}
        if(sl<=5){
          gathered = gathered + 5*c5[hp]*0.03
          ds[hp] = c5[hp]*0.025
          c5[hp] = c5[hp] - c5[hp]*0.03
          totalCaught = c5[hp]*0.03
          avgSize = c5[hp]*0.03*5}
        if(sl<=6){
          gathered = gathered + 6*c6[hp]*0.03
          ds[hp] = c6[hp]*0.025
          c6[hp] = c6[hp] - c6[hp]*0.03
          totalCaught = c6[hp]*0.03
          avgSize = c6[hp]*0.03*6}
        
      } else{
        if(sl<=1){
          gathered = gathered + c1[hp]*0.05
          c1[hp] = c1[hp] - c1[hp]*0.05
          totalCaught = c1[hp]*0.05
          avgSize = c1[hp]*0.05}
        if(sl<=2){
          gathered = gathered + 2* c2[hp]*0.05
          c2[hp] = c2[hp] - c2[hp]*0.05
          totalCaught = c2[hp]*0.05
          avgSize = c2[hp]*0.05*2}
        if(sl<=3){
          gathered = gathered + 3* c3[hp]*0.05
          c3[hp] = c3[hp] - c3[hp]*0.05
          totalCaught = c3[hp]*0.05
          avgSize = c3[hp]*0.05*3}
        if(sl<=4){
          gathered = gathered + 4* c4[hp]*0.05
          c4[hp] = c4[hp] - c4[hp]*0.05
          totalCaught = c4[hp]*0.05
          avgSize = c4[hp]*0.05*4}
        if(sl<=5){
          gathered = gathered + 5* c5[hp]*0.05
          c5[hp] = c5[hp] - c5[hp]*0.05
          totalCaught = c5[hp]*0.05
          avgSize = c5[hp]*0.05*5}
        if(sl<=6){
          gathered = gathered + 6* c6[hp]*0.05
          c6[hp] = c6[hp] - c6[hp]*0.05
          totalCaught = c6[hp]*0.05
          avgSize = c6[hp]*0.05*6}
      }

      weight = gathered/10
      sacksTaken = sacksTaken + weight/110
      harvTime = harvTime + 1
      avgSize = avgSize/totalCaught
      
      d[hp]=c1[hp]*1+c1[hp]*2+c1[hp]*3+c1[hp]*4+c1[hp]*5+c1[hp]*6
      hp=hp+1
    }
  }
  shell = 0
  for(i in 1:nplts){
    ds[i]=ds[i]*shellDecay+(c6[i]*sa*6+c5[i]*sa*5+c4[i]*sa*4+c3[i]*sa*3+c2[i]*sa*2+c1[i]*sa)
    c6[i]=c6[i]*sa+c5[i]*sa
    c5[i]=c4[i]*sa
    c4[i]=c3[i]*sa
    c3[i]=c2[i]*sa
    c2[i]=c1[i]*sa
    
    shell = d[i]+ds[i]
    cap = 0
    if(shell>md)
      shell=md
    if(shell>md-d[i])
      cap = md-d[i]
    else
      cap = shell
    if(sp[i]*sj>cap)
      c1[i]=cap
    else
      c1[i] = sp[i]*sj
    
    sp[i]=c1[i]*300+c2[i]*300+c3[i]*300+c4[i]*300+c5[i]*300+c6[i]*300
    
    if(i>1 & d[i-1]>=md){
      sp[i]=sp[i]+c1[i-1]*20+c2[i-1]*20+c3[i-1]*20+c4[i-1]*20+c5[i-1]*20+c6[i-1]*20
    }
    if(i<nplts & d[i+1]>=md){
      sp[i]=sp[i]+c1[i+1]*20+c2[i+1]*20+c3[i+1]*20+c4[i+1]*20+c5[i+1]*20+c6[i+1]*20
    }
    if(i>10 & d[i-10]>=md){
      sp[i]=sp[i]+c1[i-10]*20+c2[i-10]*20+c3[i-10]*20+c4[i-10]*20+c5[i-10]*20+c6[i-10]*20
    }
    if(i<(nplts-10) & d[i+1]>=md){
      sp[i]=sp[i]+c1[i+10]*20+c2[i+10]*20+c3[i+10]*20+c4[i+10]*20+c5[i+10]*20+c6[i+10]*20
    }
    
    d[i]=c1[i]*1+c2[i]*2+c3[i]*3+c4[i]*4+c5[i]*5+c6[i]*6
    if(d[i]>md)
      d[i]=md
    
    if(d[i]<0)
      d[i]=0
    
    if(c1[i]<0)
      c1[i]=0
    if(c2[i]<0)
      c2[i]=0
    if(c3[i]<0)
      c3[i]=0
    if(c5[i]<0)
      c4[i]=0
    if(c5[i]<0)
      c5[i]=0
    if(c6[i]<0)
      c6[i]=0
    if(sp[i]<0)
      sp[i]=0
  }
  return(list(avgSize = avgSize, harvTime = harvTime, sacksTaken = sacksTaken, c1=c1, c2=c2, c3=c3, c4=c4, c5=c5, c6=c6, ds=ds, d=d, sp=sp))
}

harvLim = 30
maxTime = 10
sizeLim = 6
harvPlot = 100
returnShells = F
param = c(maxDens, harvLim, maxTime, sizeLim, harvPlot, returnShells)

update<-harvest(spat, size1, size2, size3, size4, size5, size6, dens, deadShell, param)
size1=update$c1
size2=update$c2
size3=update$c3
size4=update$c4
size5=update$c5
size6=update$c6
spat=update$sp
update
