#Modified from https://rstudio.github.io/leaflet/shiny.html
#Some useful explanation about leaflet: https://rstudio.github.io/leaflet/popups.html

# Load libraries

rm(list=ls())
library(shiny)
library(leaflet)
library(maps)

# Make a list of colors for us to use

r_colors <- rgb(t(col2rgb(colors()) / 255))
names(r_colors) <- colors()

unique.cities=c('None',sort(unique(world.cities$country.etc)))

# define user interface using fluid page

ui <- fluidPage(
  
  # 1) add a title panel. 
  
  titlePanel('Map of big cities'),
  
  # 4)	Create a side bar that will collect all 
  # the input that we want from the user (e.g., 
  # minimum population size and desired country)
  
  sidebarLayout(
    sidebarPanel(
      numericInput("pop.thresh", label='Minimum Population size',
                   value = "3000000", width = NULL),
      
      # 2)	Add a drop down list to allow users to subset 
      # only the cities that belong to a particular country
      
      selectInput(inputId='country',label='Select country',
                  choices=unique.cities,selected='None'),
      
      # 3)	Add a radio button that allow users to subset 
      # only the capital cities.
      
      radioButtons(inputId='capital',label='Just capitals?',
        choices = c('No','Yes'),selected = 'No')
    ),
    mainPanel(
      leafletOutput("mymap")  
    )
  )
)

server <- function(input, output, session) {

  # input=list()
  # input$pop.thresh=3000000
  # input$country='None'
  # input$capital='Yes'
  
  # build an output object using renderLeaflet({}) a reactive object!
  
  output$mymap <- renderLeaflet({
    
    # make cond, a reactive value based on user input
    # filter world pop to only those cities with population larger than
    # the user's input in the numeric input
    
    
    cond=world.cities$pop>input$pop.thresh
    
    # Add logical conditions depending on user inputs
    
    if (input$country!='None') cond=cond & world.cities$country.etc==input$country
    if (input$capital=='Yes') cond=cond & world.cities$capital==1
    
    # define the spatial points data from the corresponding cities.
    
    points <- world.cities[cond,]; dim(points)

    # make a leaflet map using the stamen tonerlite provider
    
    
    my_map= leaflet() %>%
      addProviderTiles(providers$Stamen.TonerLite,
                       options = providerTileOptions(noWrap = TRUE)
      )
    
    if (sum(cond)>0)  my_map=addMarkers(map=my_map,lng=points$long,lat=points$lat,
                                 label=points$name)
    my_map
  })
}

shinyApp(ui, server)