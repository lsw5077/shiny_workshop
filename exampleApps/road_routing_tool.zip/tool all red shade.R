rm(list=ls(all=TRUE))
# Shiny app for exploring health facility distributions

library(shiny)
library(ggplot2)

# Define UI 
ui <- fluidPage(
  
  titlePanel("Determining the optimal location of roads"),
  
  sidebarLayout(
    sidebarPanel(
      textInput("road.cost", label="Road cost (per km)", value='1',placeholder=''),
      textInput("pa.cost", label="Cost of deforesting PA (per 1 km2 pixel)", value='1',placeholder=''),
      textInput("forest.cost", label="Cost of deforesting forested UA (per 1 km2 pixel)", value='1',placeholder=''),
      textInput("protect", label="Protective effect of PA in reducing deforestation (%)", value='30',placeholder=''),
      conditionalPanel(
        condition = "input.tipo == 'user-defined'",
        textInput("x", label="x coordinates", value='10,10',placeholder='0-100'),
        textInput("y", label="y coordinates", value='10,90',placeholder='0-100')
      ),
      radioButtons(inputId = "tipo", 
                   label = "Road layout", 
                   choices = c('straight line', 'user-defined','optimized'),
                   selected='straight line')
    ),
    mainPanel(
      plotOutput("LULC")
    )
  )
)

# Define server logic 
server <- function(input, output) {
  
  setwd('U:\\uf\\sesync course\\3 value based param\\conservation tool')
  source('tool functions.R')
  optim1=read.csv('optimized tabulate results.csv',as.is=T)
  grid1=read.csv('fake data gridded.csv',as.is=T)
  tmp=read.csv('glm table.csv',as.is=T)
  coef1=tmp[,'Estimate']
  names(coef1)=tmp$X
  
  #get distance to urban centers
  uc=data.frame(x=c(10,10),y=c(10,90))
  dist=numeric()
  for (i in 1:nrow(uc)){
    x2=(grid1$x-uc$x[i])^2
    y2=(grid1$y-uc$y[i])^2
    dist=cbind(dist,sqrt(x2+y2))
  }
  grid1$dist_uc=apply(dist,1,min)
  
  #input stuff
  # input=list();
  # input$road.cost='1'
  # input$pa.cost='2'
  # input$forest.cost='1'
  # input$tipo='straight line'
  # input$protect='1'
  
  output$LULC <- renderPlot({
    road.cost=as.numeric(input$road.cost) #per length of road
    pa.cost=as.numeric(input$pa.cost) #per area of deforested pa
    forest.cost=as.numeric(input$forest.cost) #per area of deforested land
    protect=as.numeric(input$protect)/100 #% of deforestation probability
    
    user.coords=data.frame(x=c(10,10),y=c(10,90))
    
    if (input$tipo=='user-defined'){
      #create user coordinates
      x=as.numeric(unlist(strsplit(input$x,split=',')))
      y=as.numeric(unlist(strsplit(input$y,split=',')))
      if (length(x)==length(y)){
        user.coords=data.frame(x=c(10,x,10),y=c(10,y,90))
      }
    }
    if (input$tipo=='optimized'){
      cost=pa.cost*(1-protect)*optim1$d.pa+forest.cost*optim1$d.ua+road.cost*optim1$l.road #change names in optim1
      ind=which(cost==min(cost))
      if (length(ind)>1) ind=ind[1]
      x=unlist(optim1[ind,c('x1','x2','x3')])
      y=unlist(optim1[ind,c('y1','y2','y3')])
      user.coords=data.frame(x=c(10,x,10),y=c(10,y,90))
    }
    
    #get nearest distance
    grid1$dist_road=get.dist(user.coords,grid1)
    
    #predict deforestation
    tmp=exp(coef1['(Intercept)']+coef1['dist_road']*grid1$dist_road+
              coef1['dist_uc']*grid1$dist_uc+
              coef1['dist_road:dist_uc']*grid1$dist_road*grid1$dist_uc)
    grid1$prob=tmp/(1+tmp)

    #get length of road
    length2=get.length(user.coords)
    
    #calculate expected cost
    tmp=calc.deforest(grid1)
    ecost=data.frame(pa.cost=pa.cost*tmp$d.pa*(1-protect),
                     road.cost=road.cost*length2,
                     forest.cost=forest.cost*tmp$d.ua)

    #change name from "Forest" to "UA"
    grid2=grid1
    cond=grid2$tipo=='Forest'
    grid2$tipo[cond]='UA'
    
    #get prob.cor (this helps displaying deforestation probability)
    cond=grid2$tipo=='PA'
    grid2$prob[cond]=grid2$prob[cond]*(1-protect)
    grid2$prob.cor=ifelse(grid2$tipo%in%c('PA','UA'),grid2$prob,0)
    
    #plot results
    res=ggplot() +
      geom_tile(data = grid2, alpha = 0.8,aes(x = x, y = y,fill = tipo)) +
      geom_path(data = user.coords, aes(x = x,y=y),show.legend=F) +
      scale_fill_manual(values=c('darkgreen','grey','green'),name='') +
      geom_point(data = user.coords, aes(x = x,y=y,size=3),show.legend=F) +
      annotate("text", x = 70, y = 96, size=4,hjust = 0,label = paste("Road cost = ",round(ecost$road.cost,0))) +
      annotate("text", x = 70, y = 92, size=4,hjust = 0,label = paste("PA cost = ",round(ecost$pa.cost,0))) +
      annotate("text", x = 70, y = 88, size=4,hjust = 0,label = paste("UA cost = ",round(ecost$forest.cost,0))) +
      annotate("text", x = 70, y = 84, size=6,hjust = 0,label = paste("Total cost = ",round(sum(unlist(ecost)),0))) +
      geom_tile(data = grid2, alpha = grid2$prob.cor,fill='red',aes(x = x, y = y))
    res
  })
}

# Run the application 
shinyApp(ui = ui, server = server)